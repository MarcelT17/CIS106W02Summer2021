gallons = int(input("Galons used for a trip:"))
miles = float(input("Enter miles traveled:"))

milespergallon = miles/gallons

print("miles per gallon are:",milespergallon)