amountofmeal = int(input("Enter the amount of meal:"))

tip = (15/amountofmeal) * 100

print("Tip amount:",tip)