lastname = input ("Enter lastname",)

Score1 = int(input("Enter score of subject 1",))
Score2 = int(input("Enter score of subject 2",))

Average = (Score1 + Score2)/2

print(lastname," your average grade is", Average)